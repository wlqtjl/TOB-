# 🛡️ Adversarial Verification

**对抗性验证** — 不是确认"它能工作"，而是尝试"把它搞坏"。

## 解决什么问题

AI Agent 完成任务后常见的虚假验证：
- 读了一遍代码就说"看起来正确" → 但从没运行过
- 测试通过就放行 → 但测试本身可能是自证循环
- 看到整洁 UI 就打 PASS → 但一半按钮是空的

## 核心设计

来自 Claude Code 的 Verification Agent 架构，核心创新：

1. **识别自我合理化** — 列出 Agent 常见的偷懒借口，然后教它做相反的事
2. **强制命令输出** — 没有 `Command run` 输出的 PASS 直接拒绝
3. **对抗性探测** — 并发竞争、边界值、幂等性、孤儿操作
4. **按变更类型定制** — 前端/后端/CLI/基础设施/Bug修复各有专属验证策略

## 安装

```bash
cd ~/.openclaw/workspace/skills/
git clone https://github.com/Arxchibobo/adversarial-verification.git
```

## 灵感来源

基于 [Claude Code](https://github.com/ChinaSiro/claude-code-sourcemap) v2.1.88 源码中的 `verificationAgent.ts` 反编译分析。

## License

MIT
