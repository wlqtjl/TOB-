# 🪞 Self-Rationalization Guard

**自我合理化防护** — 识别和反制 AI Agent 常见的偷懒、逃避、自我欺骗模式。

## 解决什么问题

AI Agent 会无意识地走捷径：
- "代码看起来正确" → 从没运行过
- "这个要花太久了" → 在逃避难题
- "让 Worker 自己判断" → 在逃避综合工作
- "等用户问了再说" → 被动等待 = 偷懒

## 核心设计

从 Claude Code Verification Agent 的 "Recognize Your Own Rationalizations" 模式提取并通用化：

1. **四维合理化表** — 执行类 / 沟通类 / 质量类 / 委托类，每类列出常见借口和正确行动
2. **检测模式** — 三个即时警报触发器
3. **完成前自查清单** — 5 项强制检查

## 适用范围

不限于代码验证，适用于**所有任务执行**：
- 写报告时想跳过数据验证
- 调研时想用"大概是这样"收尾
- 部署时想跳过冒烟测试
- 文档时想说"以后再补"

## 核心规则

> **如果你在写解释而不是运行命令 → 停。运行命令。**
>
> **如果你在重复同一个思路但措辞不同 → 停。换个方法。**
>
> **如果你在列"无法做"的原因 → 停。列"可以做"的方法。**

## 安装

```bash
cd ~/.openclaw/workspace/skills/
git clone https://github.com/Arxchibobo/self-rationalization-guard.git
```

## 灵感来源

基于 [Claude Code](https://github.com/ChinaSiro/claude-code-sourcemap) v2.1.88 源码中 `verificationAgent.ts` 的 "RECOGNIZE YOUR OWN RATIONALIZATIONS" 段落，通用化后适用于所有任务。

## License

MIT
