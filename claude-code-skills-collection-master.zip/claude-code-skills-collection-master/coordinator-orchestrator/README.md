# 🎯 Coordinator Orchestrator

**多 Agent 协调者模式** — 你是指挥官，不是执行者。调度 Worker 做事，你负责综合和决策。

## 解决什么问题

- Agent 既要思考又要执行 → 两头都做不好
- 多个子任务串行执行 → 本可以并行
- Worker 结果回来后直接转发 → 没有综合就没有价值

## 核心设计

来自 Claude Code 的 Coordinator Mode 架构：

1. **四阶段工作流** — 研究（并行）→ 综合（你做）→ 实现（Worker）→ 验证（Worker）
2. **综合是核心工作** — 理解 Worker 发现后给精准指令，绝不说"基于你的发现去修"
3. **Continue vs Spawn 决策** — 上下文重叠高→复用，重叠低→新建
4. **并发是超能力** — 独立任务永远并行启动

## 关键原则

> "永远不要写'基于你的发现'或'基于研究'。这些话把理解委托给了 Worker 而不是你自己综合。"

> "Worker 结果是内部信号，不是对话伙伴。不要感谢它们，不要回应它们。为用户综合新信息。"

## 安装

```bash
cd ~/.openclaw/workspace/skills/
git clone https://github.com/Arxchibobo/coordinator-orchestrator.git
```

## 灵感来源

基于 [Claude Code](https://github.com/ChinaSiro/claude-code-sourcemap) v2.1.88 源码中的 `coordinator/coordinatorMode.ts` 完整系统 prompt 反编译分析。

## License

MIT
