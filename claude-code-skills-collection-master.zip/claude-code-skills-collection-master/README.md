# Claude Code Skills Collection

从 [ChinaSiro/claude-code-sourcemap](https://github.com/ChinaSiro/claude-code-sourcemap) 泄露仓库收束整理的 8 个 Agent Skill，覆盖 Claude Code / AI Agent 的核心工程模式。

## Skills 列表

| Skill | 描述 |
|-------|------|
| [adversarial-verification](./adversarial-verification/) | 🛡️ 对抗性验证 — 不是确认"它能工作"，而是尝试"把它搞坏" |
| [smart-memory-guard](./smart-memory-guard/) | 🧠 记忆防膨胀 + 防漂移 — 解决 AI Agent 记忆文件无限增长、过时记忆误导行动的问题 |
| [lightweight-explorer](./lightweight-explorer/) | 🔍 轻量探索模式 — 用最少 token 完成代码搜索和调研 |
| [coordinator-orchestrator](./coordinator-orchestrator/) | 🎯 多 Agent 协调者模式 — 调度 Worker 做事，负责综合和决策 |
| [worker-prompt-craft](./worker-prompt-craft/) | ✍️ 子代理 Prompt 编写指南 — 写出让子代理一次做对的 prompt |
| [memory-type-system](./memory-type-system/) | 📝 结构化记忆类型系统 — 四类型分类 + frontmatter 规范 + 写入/召回/漂移防护全流程 |
| [self-rationalization-guard](./self-rationalization-guard/) | 🪞 自我合理化防护 — 识别和反制 AI Agent 常见的偷懒、逃避、自我欺骗模式 |
| [task-concurrency-patterns](./task-concurrency-patterns/) | ⚡ 任务并发与依赖管理 — 多 Agent/多步骤任务的并发安全、读写分离、依赖编排 |

## 来源

原始仓库由 [Arxchibobo](https://github.com/Arxchibobo) 发布，基于 [ChinaSiro/claude-code-sourcemap](https://github.com/ChinaSiro/claude-code-sourcemap) 收束整理。
