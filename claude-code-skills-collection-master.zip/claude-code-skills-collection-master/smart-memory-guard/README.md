# 🧠 Smart Memory Guard

**记忆防膨胀 + 防漂移** — 解决 AI Agent 记忆文件无限增长、过时记忆误导行动的问题。

## 解决什么问题

- MEMORY.md 越写越大，什么都往里塞 → 噪音淹没信号
- 记忆说"函数 X 在 line 42" → 但代码早就改了，Agent 还在用旧信息行动
- 不知道什么该记什么不该记 → 代码模式、git 历史全往记忆里写

## 核心设计

来自 Claude Code 的 Memory System 架构：

1. **四类型分类** — user（用户画像）/ feedback（纠正确认）/ project（项目状态）/ reference（外部指针）
2. **NOT-to-save 列表** — 6 类内容即使用户说"记住"也不存（代码模式、git 历史、调试方案...）
3. **漂移防护** — 基于记忆行动前必须验证（文件存在？函数还在？）
4. **反馈记忆带 Why** — 不只记"不要做 X"，还记"因为 Y"和"在 Z 场景应用"

## 实测效果

大波比 MEMORY.md：13.4KB → 5.0KB（精简 62%），信噪比显著提升。

## 安装

```bash
cd ~/.openclaw/workspace/skills/
git clone https://github.com/Arxchibobo/smart-memory-guard.git
```

## 灵感来源

基于 [Claude Code](https://github.com/ChinaSiro/claude-code-sourcemap) v2.1.88 源码中的 `memdir/memoryTypes.ts` + `memdir/memdir.ts` 反编译分析。

## License

MIT
